<?php

return [
    'Because she competes with no one, no one can compete with her.',
    'The best athlete wants his opponent at his best.',
    'Nothing in the world is as soft and yielding as water.',
    'Be like water.',
    'In work, do what you enjoy.',
    'Care about people\'s approval and you will be their prisoner.',
    'Do your work, then step back.',
    'Success is as dangerous as failure.',
    'The Master doesn\'t talk, he acts.',
    'A good traveler has no fixed plans and is not intent upon arriving.',
    'Knowing others is intelligence; knowing yourself is true wisdom.',
    'If your happiness depends on money, you will never be happy with yourself.',
    'If you look to others for fulfillment, you will never truly be fulfilled.',
    'The whole world belongs to you',
    'Stop trying to control.',
];
