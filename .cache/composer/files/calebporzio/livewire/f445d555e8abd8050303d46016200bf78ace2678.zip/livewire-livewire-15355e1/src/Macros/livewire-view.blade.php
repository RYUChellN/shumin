@extends($layout)

@section($section)
    @livewire($component, ...$componentOptions)
@endsection
