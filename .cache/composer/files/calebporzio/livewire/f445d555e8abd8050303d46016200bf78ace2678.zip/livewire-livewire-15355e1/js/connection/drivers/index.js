import http from './http'

export default { http }
